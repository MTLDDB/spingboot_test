create
  definer = kingshard@`%` procedure createTable251()
BEGIN 
				DECLARE `@num` INT(11);
				DECLARE `@tableName` VARCHAR(250);
        DECLARE `@i` INT(11);     
        DECLARE `@createSql` VARCHAR(2560); 
        DECLARE `@createIndexSql1` VARCHAR(2560);     
        DECLARE `@createIndexSql2` VARCHAR(2560);
        DECLARE `@createIndexSql3` VARCHAR(2560);
        DECLARE `@j` VARCHAR(10);

				SET `@num`=2;
				-- SET `@tableName`=tt_additional_resources;
        SET `@i`=0; 
        WHILE  0< `@num` DO   
        
          IF `@i` < 10 THEN
             SET `@j` = CONCAT("000",`@i`);
          ELSE
             SET `@j` = CONCAT("00",`@i`);
          END IF;
        
    
                            -- `M_ID` bigint AUTO_INCREMENT PRIMARY KEY NOT NULL,
                            -- 创建表        
--                             SET @createSql = CONCAT('CREATE TABLE IF NOT EXISTS tt_detailedinfo_',`@j`,'(
--   `objectid` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
--   `img` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "image",
--   `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `packaging` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `domain` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `webmpn` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "Digi-key Part Number",
--   `stock` int(255) NULL DEFAULT NULL COMMENT "Quantity Available	",
--   `factory_stock` int(255) NULL DEFAULT NULL COMMENT "Factory Stock",
--   `moq` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT "最小起订量",
-- 	`spq` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT "标准包装",
--   `man` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "Manufacturer",
--   `manhref` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `mpn` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "Manufacturer Part Number",
--   `descript` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "Description",
--   `leadtime` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "Manufacturer Standard Lead Time",
--   `detailed` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT "Detailed Description",
--   `pdfs` varchar(1024) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `first_classification` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `secondary_classification` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `threelevel_classification` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
-- 	`obligate1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT "保留字段",
--   `obligate2` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `obligate3` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `obligate4` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
--   `creattime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
--   PRIMARY KEY (`objectid`) USING BTREE
-- ) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;
-- '
--                             ); 
						
														SET @alterT =CONCAT('ALTER TABLE  tt_additional_resources_',`@j`,' modify column `othernames` varchar(2048);');
													PREPARE stmt2 FROM @alterT; 
                           EXECUTE stmt2;  
-- 													SET @delectT =CONCAT('DROP TABLE IF EXISTS tt_detailedinfo_',`@j`,';');
-- 														PREPARE stmt1 FROM @delectT; 
                         --   EXECUTE stmt1;   
														
                           -- PREPARE stmt FROM @createSql; 
                          --  EXECUTE stmt;                             
                        
                            -- 创建索引    
                          --  SET @createIndexSql1  = CONCAT('create index `newsid` on table_',`@j`,'(`newsid`);');
                          --  PREPARE stmt FROM @createIndexSql1; 
                         --   EXECUTE stmt; 
SET `@i`= `@i`+1; 
SET `@num`=`@num`-1;
END WHILE;
END;

